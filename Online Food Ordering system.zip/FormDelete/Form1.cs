﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodOrderingSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\our project\.vs.mdf;Integrated Security=True;Connect Timeout=30");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        public static string User;
        private void button1_Click(object sender, EventArgs e)
        {
            /* this.Hide();
              userForm User = new userForm();
              User.Show(); */
            User = unameTb.Text;

            if (unameTb.Text=="" || PasswordTb.Text == "")
            {
                MessageBox.Show("Please Enter username or password");
            }
            else
            {
                con.Open();
                SqlDataAdapter sad = new SqlDataAdapter("Select count(*) from UserTbl where Uname='" + unameTb.Text + "'and UPassword='" + PasswordTb.Text + "'", con);
                DataTable dt = new DataTable();
                sad.Fill(dt);
                if (dt.Rows[0][0].ToString()== "1")
                {
                    this.Hide();
                    UserOrder Uorder = new UserOrder();
                    Uorder.Show();
                    this.Hide();
                }
                
                else 
                {
                    MessageBox.Show("Wrong username or password");
                }

                con.Close();
            }
               
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserOrder Login = new UserOrder();
            Login.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
