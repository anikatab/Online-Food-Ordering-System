﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoodOrderingSystem
{
    public partial class UserOrder : Form
    {
        public UserOrder()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\our project\.vs.mdf;Integrated Security=True;Connect Timeout=30");

        void populate()
        {
            con.Open();
            string query = "select * from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemGV.DataSource = ds.Tables[0];
            con.Close();
        }
        void Filterbycategory()
        {
            con.Open();
            string query = "select * from ItemTbl where ItemCat='"+CatCb.SelectedItem.ToString()+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            User uform = new User();
            uform.Show();
        }
        int num = 0;
        int total, price, qty;
        string item, cat;

        private void AddToCartBtn_Click(object sender, EventArgs e)
        {
            if (QtyTb.Text == "")
            {
                MessageBox.Show("What is the Quantity?");

            }
            else if (flag==0)
            {
                MessageBox.Show("Select the product to be ordered");
            }
            else
            {
                num = num + 1;
                total=price*Convert.ToInt32(QtyTb.Text);
                table.Rows.Add(num, item, cat, price, total);
                OrderGV.DataSource = table;
                flag = 0;
                    }
            sum = sum + total;
            OrderAmtlbl.Text = "" + sum;
        }
        DataTable table= new DataTable();

        int flag = 0;
        int sum = 0;

        private void OrderAmtlbl_Click(object sender, EventArgs e)
        {

        }

        private void CatCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Filterbycategory();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void PlaceOrderBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "insert into OrdersTbl values(" + OrderNumTb.Text + ",'" + SellerNameTb.Text + "'," + OrderAmtlbl.Text + ")";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Order Successfully Created");
            con.Close();
        }

        private void UserOrder_Load(object sender, EventArgs e)
        {
            populate();
            table.Columns.Add("Num", typeof(int));
            table.Columns.Add("ItemName", typeof(String));
            table.Columns.Add("Category", typeof(String));
            table.Columns.Add("UnitPrice", typeof(int));
            table.Columns.Add("Total", typeof(int));
            OrderGV.DataSource = table;
            SellerNameTb.Text = Form1.User;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void itemGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            item = ItemGV.SelectedRows[0].Cells[1].Value.ToString();
            cat = ItemGV.SelectedRows[0].Cells[2].Value.ToString();
            price = Convert.ToInt32 (ItemGV.SelectedRows[0].Cells[3].Value.ToString());
            flag = 1;
        }
    }
}
