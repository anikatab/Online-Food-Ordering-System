﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Linq.Expressions;

namespace FoodOrderingSystem
{
    public partial class User : Form
    {
        public User()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\our project\.vs.mdf;Integrated Security=True;Connect Timeout=30");
        
        void populate()
        {
            con.Open();
            string query = "select * from UserTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query,con);
            SqlCommandBuilder builder= new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            UsersGV.DataSource= ds.Tables[0];
                con.Close();
        }
        private void User_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 Login = new Form1();
            Login.Show();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "insert into UserTbl values('"+unameTb.Text+"','"+upassTb.Text+"','"+upassTb.Text + "')";
            SqlCommand cmd=new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("User Successfully Created");
            con.Close();
            populate();
            reset();     
        }

        private void UsersGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            unameTb.Text = UsersGV.SelectedRows[0].Cells[0].Value.ToString();
            uphoneTb.Text = UsersGV.SelectedRows[0].Cells[1].Value.ToString();
            upassTb.Text = UsersGV.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
           try
            {
                con.Open();
                string query = "deleted from UserTbl where Uphone='" + uphoneTb.Text + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User Successfully deleted");
                populate();
                con.Close();
                reset();
            }
            catch (Exception Ex)
                {
                MessageBox.Show(Ex.Message);
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if(unameTb.Text=="" || uphoneTb.Text==""|| upassTb.Text==)
            {
                MessageBox.Show("Fill all the Field");
            }
            else
            {
                con.Open();
                string query = "update UserTbl set Uname= '" + unameTb.Text + "', Upassword='" + upassTb.Text + "'where Uphone='" + uphoneTb.Text + "'";
                SqlCommand cmd =new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Users successfully updated");
                con.Close();
                populate();
                reset();

            }

            
        }

        public void reset()
        {
            unameTb.Text = "";
            upassTb.Text = "";
            uphoneTb.Text = "";
        }

        private void upassTb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
